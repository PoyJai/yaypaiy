const CarApp = {
    data: [
        {
            id: 1, brand: "มรดกโลก", name: "อุทยานประวัติศาสตร์กำแพงเพชร", price: "ค่าเข้าชม 20-40 บาท",
            img: "https://lh3.googleusercontent.com/proxy/KqUOUysJyx7lAm3gjrb88PVhI9o2s-uB6Y5H8uHDA_EK3TE7jJXyrEVyK-LW2sBGGPTEaT45wqiesjKnM6Nsl99GrTfYUCzoVs_QI9Jtv2iJuWlAgM5AHcnfG7HBjxeS",
            specs: ["โบราณสถาน", "UNESCO", "ศิลาแลง"],
            desc: "มรดกโลกทางวัฒนธรรมที่สะท้อนความรุ่งเรืองในอดีต โดดเด่นด้วยวัดวาอารามที่สร้างจากศิลาแลงขนาดใหญ่ท่ามกลางป่าไม้อันร่มรื่น"
        },
        {
            id: 2, brand: "ธรรมชาติ", name: "อุทยานแห่งชาติคลองลาน", price: "ค่าเข้าชมตามอัตราอุทยาน",
            img: "https://travel.trueid.net/detail/yYp87A3An8m6",
            img: "https://upload.wikimedia.org/wikipedia/commons/5/56/Klonglan_waterfall_01.jpg",
            specs: ["น้ำตกใหญ่", "ถ่ายรูปสวย", "พักผ่อน"],
            desc: "น้ำตกคลองลาน เป็นน้ำตกขนาดใหญ่และสวยงามที่สุดแห่งหนึ่งในไทย สายน้ำตกที่ตกลงมาจากหน้าผาสูงสร้างละอองน้ำเย็นฉ่ำตลอดปี"
        },
        {
            id: 3, brand: "ธรรมชาติ", name: "ช่องเย็น (แม่วงก์)", price: "จุดกางเต็นท์ยอดนิยม",
            img: "https://static.thairath.co.th/media/Dtbezn3nNUxytg04aobCXQVpeKrH4S8I8J7PMndaOnKeC7.jpg",
            specs: ["อากาศหนาว", "ดูนก", "ทะเลหมอก"],
            desc: "จุดสูงสุดของอุทยานแห่งชาติแม่วงก์ มีอากาศหนาวเย็นตลอดปี เป็นสวรรค์ของนักดูนกและผู้ที่ชื่นชอบการแช่ตัวในทะเลหมอกยามเช้า"
        },
        {
            id: 4, brand: "พักผ่อน", name: "บ่อน้ำพุร้อนพระร่วง", price: "ค่าบริการแช่น้ำ 30-50 บาท",
            img: "https://storage.googleapis.com/tripniceday/uploads/places/1626691558440.jpg",
            specs: ["น้ำแร่ธรรมชาติ", "สุขภาพ", "สปา"],
            desc: "ผ่อนคลายความเมื่อยล้าด้วยการแช่น้ำพุร้อนธรรมชาติที่ไม่มีกลิ่นกำมะถัน มีทั้งบ่อแช่เท้าฟรีและห้องอาบน้ำแร่ส่วนตัว"
        },
        {
            id: 5, brand: "ประวัติศาสตร์", name: "วัดพระแก้ว", price: "ใจกลางเมืองเก่า",
            img: "https://cms.dmpcdn.com/travel/2022/09/05/473cef80-2cd7-11ed-a360-93980c2d578b_webp_original.jpg",
            specs: ["วัดสำคัญ", "พระนอนองค์ใหญ่", "ศิลปะสุโขทัย"],
            desc: "วัดที่ใหญ่ที่สุดในเขตอุทยานประวัติศาสตร์กำแพงเพชร ภายในมีพระพุทธรูปปางไสยาสน์และพระเจดีย์ทรงกลมฐานสิงห์ล้อมที่งดงาม"
        }
    ],

    init() {
        this.renderList();
    },

    renderList() {
        const container = document.getElementById('car-list-container');
        if(!container) return;
        container.innerHTML = this.data.map(item => `
            <div class="card" onclick="CarApp.openDetail(${item.id})">
                <div class="card-img-container">
                    <img src="${item.img}" alt="${item.name}" class="product-img">
                </div>
                <div class="card-body">
                    <span class="brand-tag">${item.brand}</span>
                    <h3 class="product-name">${item.name}</h3>
                    <div class="price-box">
                        <span class="price">${item.price}</span>
                        <button class="btn-view">ดูรายละเอียด</button>
                    </div>
                </div>
            </div>
        `).join('');
    },

    showPage(pageId) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById(pageId).classList.add('active');
        window.scrollTo(0,0);
    },

    openDetail(id) {
        const item = this.data.find(p => p.id === id);
        const view = document.getElementById('detail-view');
        view.innerHTML = `
            <button class="btn-back" onclick="CarApp.showPage('home')">← กลับหน้าหลัก</button>
            <div class="detail-container">
                <div class="detail-img-box">
                    <img src="${item.img}" alt="${item.name}">
                </div>
                <div class="detail-info">
                    <span class="brand-tag">${item.brand}</span>
                    <h2>${item.name}</h2>
                    <p class="detail-price">${item.price}</p>
                    <p class="detail-desc">${item.desc}</p>
                    <div class="detail-specs-grid">
                        <div class="spec-item"><strong>ประเภท</strong><p>${item.specs[0]}</p></div>
                        <div class="spec-item"><strong>ไฮไลท์</strong><p>${item.specs[1]}</p></div>
                        <div class="spec-item"><strong>วัสดุ/ลักษณะ</strong><p>${item.specs[2]}</p></div>
                    </div>
                    <button class="btn-view" style="width:100%; padding:1rem; margin-top:1.5rem;" onclick="window.open('https://www.google.com/maps/search/${item.name}')">เปิดแผนที่การเดินทาง</button>
                </div>
            </div>
        `;
        this.showPage('detail');
    }
};

window.onload = () => CarApp.init();